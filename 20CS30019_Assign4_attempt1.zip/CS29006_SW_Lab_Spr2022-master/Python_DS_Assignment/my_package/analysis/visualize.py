#Imports
from PIL import Image, ImageDraw
import numpy as np

def plot_visualization(image,gt_bboxes,get_png_ann): # Write the required arguments

  #mask_coords= coordinates to make the seg map
  #box_coords+box coords to make the bounding box
  #str_text=the name which should be printed on the bounding box

  # The function should plot the predicted segmentation maps and the bounding boxes on the images and save them.
  # Tip: keep the dimensions of the output image less than 800 to avoid RAM crashes.

  img=Image.fromarray(np.uint8(image)) #keeping the dimensions within 800
  drawing=ImageDraw.Draw(img)
  str_text,left,top,width,height=gt_bboxes #taking the coordinates of box predicted
  drawing.rectangle([left,top,left+width,height+top],fill=None,outline="yellow",width=1)#drawing the rectangle
  drawing.text([left,top],str_text,fill="blue")#writing the text
  #making the segmentation mask

  drawing.show()#finally displaying the image