#Imports
import numpy as np
import json
from PIL import Image
from torch.utils.data import dataset
#importing the various transform functions which can be used
from my_package.data.transforms.blur import BlurImage
from my_package.data.transforms.crop import CropImage
from my_package.data.transforms.flip import FlipImage
from my_package.data.transforms.rescale import RescaleImage
from my_package.data.transforms.rotate import RotateImage
import os
import re
from unicodedata import category
from unittest import result

class Dataset(object):
    '''
        A class for the dataset that will return data items as per the given index
    '''

    def __init__(self, annotation_file, transforms = None):
        '''
            Arguments:
            annotation_file: path to the annotation file
            transforms: list of transforms (class instances)
                        For instance, [<class 'RandomCrop'>, <class 'Rotate'>]
        '''
        with open(annotation_file) as file:
            self.attn=json.loads('['+re.sub(r'\}\s\{','},{', file.read())+']')

        self.transforms=transforms
        
        

    def __len__(self):
        '''
            return the number of data points in the dataset
        '''
        return len(self.attn)

    def __getitem__(self, idx):
        '''
            return the dataset element for the index: "idx"
            Arguments:
                idx: index of the data element.

            Returns: A dictionary with:
                image: image (in the form of a numpy array) (shape: (3, H, W))
                gt_png_ann: the segmentation annotation image (in the form of a numpy array) (shape: (1, H, W))
                gt_bboxes: N X 5 array where N is the number of bounding boxes, each 
                            consisting of [class, x1, y1, x2, y2]
                            x1 and x2 lie between 0 and width of the image,
                            y1 and y2 lie between 0 and height of the image.

            You need to do the following, 
            1. Extract the correct annotation using the idx provided.
            2. Read the image, png segmentation and convert it into a numpy array (wont be necessary
                with some libraries). The shape of the arrays would be (3, H, W) and (1, H, W), respectively.
            3. Scale the values in the arrays to be with [0, 1].
            4. Perform the desired transformations on the image.
            5. Return the dictionary of the transformed image and annotations as specified.
        '''
        ans={}

        path='data/'+self.attn[idx]["img_fn"]
        attn_path='data/'+self.attn[idx]["png_ann_fn"]
        pic=Image.open(path)
        attn_pic=Image.open(attn_path)

        for instance_trans in self.transforms:
            pic=instance_trans.__call__(pic)
        
        image= np.array(attn_pic)/255
        image=np.rollaxis(image,2,0)
        
        gt_png_ann=np.array(attn_pic)/255
        gt_png_ann=np.rollaxis(gt_png_ann.reshape(*(gt_png_ann.shape),1),2,0)

        ans["gt_png_ann"]=gt_png_ann
        ans["gt_bboxes"]=[]
        ans["image"]=image

        for i in self.attn[idx]["bboxes"]:
            ans["gt_bboxes"].append([i["category"]]+i["box"])


        ans["gt_bboxes"]=np.array(ans["gt_bboxes"]) 
        
        return ans  

        