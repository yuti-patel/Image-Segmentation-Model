#Imports
from PIL import Image
import random


class CropImage(object):
    '''
        Performs either random cropping or center cropping.
    '''

    def __init__(self, shape, crop_type='center'):
        '''
            Arguments:
            shape: output shape of the crop (h, w)
            crop_type: center crop or random crop. Default: center
        '''

        # Write your code here

        #accepting the new width and the new height of the cropped image
        self.crop_h,self.crop_w=shape
        self.crop_type=crop_type #here the configuration

    def __call__(self, image):
        '''
            Arguments:
            image (numpy array or PIL image)

            Returns:
            image (numpy array or PIL image)
        '''

        # Write your code here
        image=Image.open(image)
        org_h,org_w=image.size   #the original dimensions of the image

        #CENTER
        if self.crop_type=="center":
            left=(org_w-self.crop_w)/2
            top=(org_h-self.crop_h)/2
            right=(org_w+self.crop_w)/2
            down=(org_h+self.crop_h)/2
        
        #LEFT TOP
        elif self.crop_type=="left top":
            left=0
            top=0
            right=self.crop_w
            down=self.crop_h

        #RIGHT TOP
        elif self.crop_type=="right top":
            left=(org_w-self.crop_w)
            top=0
            right=org_w
            down=self.crop_h
        
        #LEFT DOWN
        elif self.crop_type=="left down":
            left=0
            top=org_h-self.crop_h
            right=self.crop_w
            down=org_h
        
        #RIGHT DOWN
        elif self.crop_type=="right down":
            left=(org_w-self.crop_w)
            top=org_h-self.crop_h
            right=org_w
            down=org_h
        
        #RANDOM SELECTION DONE IF NO CROP TYPE IS MENTIONED
        else :
            left=random.randint(0,org_w-self.crop_w)
            top=random.randint(0,org_h-self.crop_h)
            right=left+self.crop_w
            down=top+self.crop_h


        area=(left,top,right,down)
        image=image.crop(area) #cropping the selected area above
        
        return image #returning the image finally after cropping it

        

 