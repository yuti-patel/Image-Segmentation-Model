#Imports
from PIL import Image

class RescaleImage(object):
    '''
        Rescales the image to a given size.
    '''

    def __init__(self, output_size):
        '''
            Arguments:
            output_size (tuple or int): Desired output size. If tuple, output is
            matched to output_size. If int, smaller of image edges is matched
            to output_size keeping aspect ratio the same.
        '''

        # Write your code here
        self.output_size=output_size

    def __call__(self, image):
        '''
            Arguments:
            image (numpy array or PIL image)

            Returns:
            image (numpy array or PIL image)

            Note: You do not need to resize the bounding boxes. ONLY RESIZE THE IMAGE.
        '''

        # Write your code here

        #TUPLE
        if isinstance(self.output_size,tuple):#if the given size is a tuple, then resize it to the given size
            image=image.resize(self.output_size[0],self.output_size[1]) #assuming the tuple is given as width,height
        
        #JUST AN INTEGER
        else :#if only an int is given, we have to resize the smallest side with the new int given and maintaining the aspect ratio same
            #we should be able to change the order side lenth accordingly

            if image.height>image.width:
                scale=self.output_size/image.width
                image=image.resize(self.output_size,(scale*image.height))

            else :
                scale=self.output_size/image.height
                image=image.resize((scale*image.width),self.output_size)
        

        return image#finally returning the resized image