#Imports
import matplotlib.pyplot as plt
from matplotlib import cm
from my_package.model import InstanceSegmentationModel
from my_package.data.dataset import Dataset
from my_package.analysis.visualize import plot_visualization
from my_package.data.transforms.blur import BlurImage
from my_package.data.transforms.crop import CropImage
from my_package.data.transforms.flip import FlipImage
from my_package.data.transforms.rescale import RescaleImage
from my_package.data.transforms.rotate import RotateImage
import numpy as np
from PIL import Image,ImageDraw

def experiment(annotation_file, segmentor, transforms, outputs):
    '''
        Function to perform the desired experiments

        Arguments:
        annotation_file: Path to annotation file
        segmentor: The image segmentor
        transforms: List of transformation classes
        outputs: path of the output folder to store the images
    '''

    #Create the instance of the dataset.
    obj_dataset=Dataset(annotation_file,transforms=transforms)
    
    #Iterate over all data items.
    data_store=[]
    for idx in range(0,obj_dataset.__len__()):
        data_store.append(obj_dataset.__getitem__(idx))

    #Get the predictions from the segmentor.
    segmen_store=[]
    for item in data_store:
        segmen_store.append(segmentor.__call__(item["image"]))
        
    #Draw the segmentation maps on the image and save them.
    for idx_i in range(len(data_store)):
        image=data_store[idx_i]["image"]
        #to check uncomment this
        #image=image+segmen_store[idx_i][1][1]
        #print(image)

        for index in range(min(3,len(segmen_store[idx_i][1]))):
            image=image+segmen_store[idx_i][1][index]
        image=np.rollaxis(image,2,0)
        image=np.rollaxis(image,2,0)*255
        drawing=Image.fromarray(np.uint8(image))
        draw=ImageDraw.Draw(drawing)

        for index in range(min(3, len(segmen_store[idx_i][1]))):
            left_corner,right_corner=segmen_store[idx_i][0][index]
            text = segmen_store[idx_i][2][index] + \
                " ("+str(segmen_store[idx_i][3][index])+")"
            draw.rectangle([left_corner[0], left_corner[1], left_corner[0]+right_corner[0],left_corner[1]+right_corner[1]], outline="orange", width=1)
            draw.text([left_corner[0], left_corner[1]-10], text, fill="#000")
        

        drawing.save(f"output/{idx_i}output.jpg")
    #Do the required analysis experiments.
    


def main():
    segmentor = InstanceSegmentationModel()
    experiment('./data/annotations.jsonl', segmentor, [FlipImage(), BlurImage()], None) # Sample arguments to call experiment()


if __name__ == '__main__':
    #print("********")
    main()
